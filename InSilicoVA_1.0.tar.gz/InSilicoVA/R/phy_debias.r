## Update on Sep 30 2015

physician_debias <- function(){

}