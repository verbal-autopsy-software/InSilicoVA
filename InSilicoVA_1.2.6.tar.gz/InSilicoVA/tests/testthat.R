library(testthat)
library(InSilicoVA)

test_check("InSilicoVA")
